import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import java.awt.Image;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;

public class Level extends JFrame {
	Image img = null;
	Font font = new Font("���� ����", Font.BOLD, 20);
	Font font2 = new Font("���� ����", Font.BOLD, 30);
	static int counter = 0;
	static String change = "";
	
	private LineBorder line1 = new LineBorder(Color.red, 5, true);
	private LineBorder line2 = new LineBorder(Color.yellow, 5, true);
	private LineBorder line3 = new LineBorder(Color.green, 5, true);
	private LineBorder line4 = new LineBorder(Color.blue, 5, true);
	private LineBorder line5 = new LineBorder(new Color(139, 0, 255), 5, true); //����
	private LineBorder line6 = new LineBorder(new Color(255, 127, 0), 5, true); //��Ȳ
	private LineBorder line7 = new LineBorder(new Color(171, 235, 0), 5, true); //����
	private LineBorder line8 = new LineBorder(new Color(0, 204, 255), 5, true); //�ϴ�
	private LineBorder line9 = new LineBorder(new Color(0, 0, 188), 5, true);   //û��
	
	
	static levelObject button1 = new levelObject("red");
	static levelObject button2 = new levelObject("yellow");
	static levelObject button3 = new levelObject("green");
	static levelObject button4 = new levelObject("blue");
	static levelObject button5 = new levelObject("purple");
	static levelObject button6 = new levelObject("gray");
	
	public static levelObject target1 = new levelObject("");
	public static levelObject target2 = new levelObject("");
	public static levelObject target3 = new levelObject("");
	public static levelObject target4 = new levelObject("");
	public static levelObject target5 = new levelObject("");
	public static levelObject target6 = new levelObject("");
	public static levelObject target7 = new levelObject("");
	
	public Level() {
		level();
	}
	
	public void level() {
		if (Game.level == 0)
			new Title();
		
		else {
			JFrame level_page = new JFrame("Level " + Game.level);
			
			JLabel level_an = new JLabel("Level " + Game.level);
			level_an.setFont(font2);
			level_an.setBounds(80, 50, 200, 60);
			level_page.add(level_an);
			
			JLabel level_text = new JLabel("Help : Choose color from the palette!");
			level_text.setFont(font);
			level_text.setBounds(30, 700, 600, 61);
			level_page.add(level_text);
			
			JLabel palette = new JLabel("PALETTE ->");
			palette.setFont(font);
			palette.setBounds(495, 603, 600, 61);
			level_page.add(palette);
			
			if (Game.level == 1) {
				JLabel g1 = new JLabel("");
				g1.setBounds(450, 320, 61, 61);
				g1.setBorder(line1);
				level_page.add(g1);
				
				JLabel g2 = new JLabel("");
				g2.setBounds(520, 320, 61, 61);
				g2.setBorder(line2);
				level_page.add(g2);
				
				JLabel g3 = new JLabel("");
				g3.setBounds(590, 180, 61, 61);
				g3.setBorder(line3);
				level_page.add(g3);
				
				JLabel g4 = new JLabel("");
				g4.setBounds(590, 460, 61, 61);
				g4.setBorder(line4);
				level_page.add(g4);
				
				JLabel g5 = new JLabel("");
				g5.setBounds(730, 250, 61, 61);
				g5.setBorder(line5);
				level_page.add(g5);
				
				JLabel g6 = new JLabel("");
				g6.setBounds(730, 320, 61, 61);
				g6.setBorder(line3);
				level_page.add(g6);
				
				JLabel g7 = new JLabel("");
				g7.setBounds(730, 390, 61, 61);
				g7.setBorder(line1);
				level_page.add(g7);
			}
			
			if (Game.level == 2) {
				JLabel g1 = new JLabel("");
				g1.setBounds(320, 320, 61, 61);
				g1.setBorder(line1);
				level_page.add(g1);
				
				JLabel g2 = new JLabel("");
				g2.setBounds(460, 320, 61, 61);
				g2.setBorder(line6);
				level_page.add(g2);
				
				JLabel g3 = new JLabel("");
				g3.setBounds(600, 320, 61, 61);
				g3.setBorder(line7);
				level_page.add(g3);
				
				JLabel g4 = new JLabel("");
				g4.setBounds(740, 320, 61, 61);
				g4.setBorder(line8);
				level_page.add(g4);
				
				JLabel g5 = new JLabel("");
				g5.setBounds(880, 320, 61, 61);
				g5.setBorder(line9);
				level_page.add(g5);
				
				JLabel g6 = new JLabel("");
				g6.setBounds(1020, 320, 61, 61);
				g6.setBorder(line5);
				level_page.add(g6);
			}
			
			if (Game.level == 3) {
				JLabel g1 = new JLabel("");
				g1.setBounds(530, 110, 61, 61);
				g1.setBorder(line1);
				level_page.add(g1);
				
				JLabel g2 = new JLabel("");
				g2.setBounds(530, 250, 61, 61);
				g2.setBorder(line5);
				level_page.add(g2);
				
				JLabel g3 = new JLabel("");
				g3.setBounds(530, 320, 61, 61);
				g3.setBorder(line2);
				level_page.add(g3);
				
				JLabel g4 = new JLabel("");
				g4.setBounds(390, 320, 61, 61);
				g4.setBorder(line3);
				level_page.add(g4);
				
				JLabel g5 = new JLabel("");
				g5.setBounds(670, 250, 61, 61);
				g5.setBorder(line3);
				level_page.add(g5);
				
				JLabel g6 = new JLabel("");
				g6.setBounds(810, 250, 61, 61);
				g6.setBorder(line2);
				level_page.add(g6);
				
				JLabel g7 = new JLabel("");
				g7.setBounds(670, 390, 61, 61);
				g7.setBorder(line5);
				level_page.add(g7);
				
				JLabel g8 = new JLabel("");
				g8.setBounds(810, 390, 61, 61);
				g8.setBorder(line5);
				level_page.add(g8);
			}
			
			if (Game.level == 4) {
				JLabel g1 = new JLabel("");
				g1.setBounds(460, 250, 61, 61);
				g1.setBorder(line7);
				level_page.add(g1);
				
				JLabel g2 = new JLabel("");
				g2.setBounds(600, 250, 61, 61);
				g2.setBorder(line6);
				level_page.add(g2);
				
				JLabel g3 = new JLabel("");
				g3.setBounds(460, 390, 61, 61);
				g3.setBorder(line8);
				level_page.add(g3);
				
				JLabel g4 = new JLabel("");
				g4.setBounds(600, 390, 61, 61);
				g4.setBorder(line5);
				level_page.add(g4);
				
				JLabel g5 = new JLabel("");
				g5.setBounds(810, 250, 61, 61);
				g5.setBorder(line5);
				level_page.add(g5);
				
				JLabel g6 = new JLabel("");
				g6.setBounds(740, 110, 61, 61);
				g6.setBorder(line1);
				level_page.add(g6);
				
				JLabel g7 = new JLabel("");
				g7.setBounds(950, 320, 61, 61);
				g7.setBorder(line2);
				level_page.add(g7);
			}
			
			if (Game.level == 5) {
				JLabel g1 = new JLabel("");
				g1.setBounds(530, 180, 61, 61);
				g1.setBorder(line9);
				level_page.add(g1);
				
				JLabel g2 = new JLabel("");
				g2.setBounds(670, 320, 61, 61);
				g2.setBorder(line3);
				level_page.add(g2);
				
				JLabel g3 = new JLabel("");
				g3.setBounds(740, 390, 61, 61);
				g3.setBorder(line8);
				level_page.add(g3);
				
				JLabel g4 = new JLabel("");
				g4.setBounds(810, 460, 61, 61);
				g4.setBorder(line2);
				level_page.add(g4);
				
				JLabel g5 = new JLabel("");
				g5.setBounds(880, 390, 61, 61);
				g5.setBorder(line6);
				level_page.add(g5);
				
				JLabel g6 = new JLabel("");
				g6.setBounds(390, 180, 61, 61);
				g6.setBorder(line4);
				level_page.add(g6);
			}
			
			JButton prev = new JButton("Prev");
			prev.setBounds(1084, 700, 100, 61);
			level_page.add(prev);
			
			JButton next = new JButton("Next");
			next.setBounds(1184, 700, 100, 61);
			level_page.add(next);
			
			JButton but1 = new JButton("");
			but1.setBackground(Color.red);
			but1.setBounds(620, 600, 70, 70);
			level_page.add(but1);
			
			JButton but2 = new JButton("");
			but2.setBackground(Color.yellow);
			but2.setBounds(720, 600, 70, 70);
			level_page.add(but2);
			
			JButton but3 = new JButton("");
			but3.setBackground(Color.green);
			but3.setBounds(820, 600, 70, 70);
			level_page.add(but3);
			
			JButton but4 = new JButton("");
			but4.setBackground(Color.blue);
			but4.setBounds(920, 600, 70, 70);
			level_page.add(but4);
			
			JButton but5 = new JButton("");
			but5.setBackground(new Color(139, 0, 255));
			but5.setBounds(1020, 600, 70, 70);
			level_page.add(but5);
			
			JButton but6 = new JButton("");
			but6.setBackground(Color.gray);
			but6.setBounds(1120, 600, 70, 70);
			level_page.add(but6);
			
			JButton but_target1 = new JButton("");
			but_target1.setBackground(Color.gray);
			but_target1.setBounds(target1.posX(1, Game.level), target1.posY(1, Game.level), 60, 60);
			level_page.add(but_target1);
			
			JButton but_target2 = new JButton("");
			but_target2.setBackground(Color.gray);
			but_target2.setBounds(target2.posX(2, Game.level), target1.posY(2, Game.level), 60, 60);
			level_page.add(but_target2);	
			
			JButton but_target3 = new JButton("");
			but_target3.setBackground(Color.gray);
			but_target3.setBounds(target3.posX(3, Game.level), target3.posY(3, Game.level), 60, 60);
			level_page.add(but_target3);	
			
			JButton but_target4 = new JButton("");
			but_target4.setBackground(Color.gray);
			but_target4.setBounds(target4.posX(4, Game.level), target4.posY(4, Game.level), 60, 60);
			level_page.add(but_target4);	
			
			JButton but_target5 = new JButton("");
			but_target5.setBackground(Color.gray);
			but_target5.setBounds(target5.posX(5, Game.level), target5.posY(5, Game.level), 60, 60);
			level_page.add(but_target5);	
			
			JButton but_target6 = new JButton("");
			but_target6.setBackground(Color.gray);
			but_target6.setBounds(target6.posX(6, Game.level), target6.posY(6, Game.level), 60, 60);
			level_page.add(but_target6);	
			
			JButton but_target7 = new JButton("");
			but_target7.setBackground(Color.gray);
			but_target7.setBounds(target7.posX(7, Game.level), target7.posY(7, Game.level), 60, 60);
			level_page.add(but_target7);	
			
			level_page.setSize(1300, 800);
			level_page.setResizable(false);
			level_page.setLocationRelativeTo(null);
			level_page.setLayout(null);
			level_page.setVisible(true);
			level_page.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			but1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button1.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Red");
					}
				}
			});
			
			but2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button2.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Yellow");
					}
				}
			});
			
			but3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button3.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Green");
					}
				}
			});
			
			but4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button4.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Blue");
					}
				}
			});
			
			but5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button5.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Purple");
					}
				}
			});
			
			but6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 0) {
						change = button6.getColor();
						counter = 1;
						level_text.setText("Help : Select a gray tile to color it! - Reset");
					}
				}
			});
			
			but_target1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target1, change);
						counter = 0;
						target1.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target2, change);
						counter = 0;
						target2.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target3, change);
						counter = 0;
						target3.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target4, change);
						counter = 0;
						target4.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target5, change);
						counter = 0;
						target5.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target6, change);
						counter = 0;
						target6.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			but_target7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (counter == 1) {
						setColor(but_target7, change);
						counter = 0;
						target7.chaColor(change);
						level_text.setText("Help : Choose color from the palette!");
						new Clear();
						if (Game.check == 1)
							level_text.setText("Level Clear!!!");
					}
				}
			});
			
			prev.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Game.level = Game.level - 1;
					new Level();
					level_page.setVisible(false);
				}
			});
			
			next.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (Game.level == 5)
						Game.level = Game.level - 1;	
					Game.level = Game.level + 1;
					new Level();
					level_page.setVisible(false);
				}
			});
		}
	}
	
	public void setColor(JButton button, String color) {
		if (color.equals("red"))
			button.setBackground(Color.red);
		
		if (color.equals("yellow"))
			button.setBackground(Color.yellow);
		
		if (color.equals("green"))
			button.setBackground(Color.green);
		
		if (color.equals("blue"))
			button.setBackground(Color.blue);
		
		if (color.equals("purple"))
			button.setBackground(new Color(139, 0, 255));
		
		if (color.equals("gray"))
			button.setBackground(Color.gray);
	}
}