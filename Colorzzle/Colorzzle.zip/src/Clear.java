public class Clear {
	private int clear_count = 0;
	
	public Clear() {
		clear();
	}
	
	public void clear() {
		Game.check = 0;
		
		if (Game.level == 1) {
			if (Level.target1.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target2.getColor() == "yellow")
				clear_count = clear_count + 1;
			if (Level.target3.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target4.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target5.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target6.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target7.getColor() == "purple")
				clear_count = clear_count + 1;
			
			if (clear_count == 7)
				Game.check = 1;
		}
		
		if (Game.level == 2) {
			if (Level.target1.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target2.getColor() == "yellow")
				clear_count = clear_count + 1;
			if (Level.target3.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target4.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target5.getColor() == "purple")
				clear_count = clear_count + 1;
			
			if (clear_count == 5)
				Game.check = 1;
		}
		
		if (Game.level == 3) {
			if (Level.target1.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target2.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target3.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target4.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target5.getColor() == "purple")
				clear_count = clear_count + 1;
			if (Level.target6.getColor() == "yellow")
				clear_count = clear_count + 1;
			if (Level.target7.getColor() == "purple")
				clear_count = clear_count + 1;
			
			if (clear_count == 7)
				Game.check = 1;
		}
		
		if (Game.level == 4) {
			if (Level.target1.getColor() == "yellow")
				clear_count = clear_count + 1;
			if (Level.target2.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target3.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target4.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target5.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target6.getColor() == "purple")
				clear_count = clear_count + 1;
			if (Level.target7.getColor() == "yellow")
				clear_count = clear_count + 1;
			
			if (clear_count == 7)
				Game.check = 1;
		}
		
		if (Game.level == 5) {
			if (Level.target1.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target2.getColor() == "purple")
				clear_count = clear_count + 1;
			if (Level.target3.getColor() == "yellow")
				clear_count = clear_count + 1;
			if (Level.target4.getColor() == "blue")
				clear_count = clear_count + 1;
			if (Level.target5.getColor() == "green")
				clear_count = clear_count + 1;
			if (Level.target6.getColor() == "red")
				clear_count = clear_count + 1;
			if (Level.target7.getColor() == "yellow")
				clear_count = clear_count + 1;
			
			if (clear_count == 7)
				Game.check = 1;
		}
	}
}
