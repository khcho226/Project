import java.util.HashMap;

public class levelObject {
	private String color;
	private int[] temp = new int[14];
	
	public levelObject(String color) {
		this.color = color;
	}
		
	public String getColor() {
		return color;
	}
	
	public void chaColor(String color) {
		this.color = color;
	}
	
	public int posX(int target, int level) {
		temp = Game.map.get(level);		
		return temp[target - 1];
	}
	
	public int posY(int target, int level) {
		temp = Game.map.get(level);
		return temp[target + 6];
	}
}