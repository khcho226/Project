import java.util.HashMap;

public class Game {
	public static int level = 0;
	public static int check = 0;
	
	public static int[] level1 = {450, 520, 590, 590, 660, 660, 730, 250, 250, 250, 390, 390, 320, 180};
	public static int[] level2 = {390, 530, 670, 810, 950, 250, 320, 320, 320, 320, 320, 320, 180, 180};
	public static int[] level3 = {530, 460, 600, 600, 600, 740, 740, 180, 320, 250, 320, 390, 250, 390};
	public static int[] level4 = {530, 460, 530, 600, 740, 880, 880, 250, 320, 390, 320, 180, 250, 320};
	public static int[] level5 = {460, 600, 600, 740, 740, 880, 880, 180, 180, 320, 320, 460, 460, 320};
	
	public static HashMap<Integer, int[]> map = new HashMap<Integer, int[]>() {{
		put(1, level1);
		put(2, level2);
		put(3, level3);
		put(4, level4);
		put(5, level5);
	}};
	
	public static void main(String[] args) {
		Title title = new Title();
	}
}