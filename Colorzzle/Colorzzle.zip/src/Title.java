import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;

public class Title extends JFrame {
	Image img = null;
	Font font = new Font("���� ����", Font.BOLD, 20);
	
	public Title() {
		title();
	}

	public void title() {
		JFrame title_page = new JFrame("Colorzzle");
		
		try {
			File title_bg = new File(".\\image\\title.png");
			img = ImageIO.read(title_bg);
		} catch (IOException e) {
			System.out.println("no image");
		};
		
		JLabel title = new JLabel(new ImageIcon(img));
		title.setLayout(null);
		title.setBounds(0, 0, 1300, 700);
		title_page.add(title);
		
		JLabel title_text = new JLabel("Welcome to Colorzzle! Press 'Next' button to start!");
		title_text.setFont(font);
		title_text.setBounds(30, 700, 600, 61);
		title_page.add(title_text);
		
		JButton next = new JButton("Next");
		next.setBounds(1184, 700, 100, 61);
		title_page.add(next);
		
		title_page.setSize(1300, 800);
		title_page.setResizable(false);
		title_page.setLocationRelativeTo(null);
		title_page.setLayout(null);
		title_page.setVisible(true);
		title_page.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Game.level = Game.level + 1;
				new Level();
				title_page.setVisible(false);
			}
		});
	}
}