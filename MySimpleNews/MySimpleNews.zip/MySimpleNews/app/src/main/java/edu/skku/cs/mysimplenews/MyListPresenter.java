package edu.skku.cs.mysimplenews;

import com.google.gson.JsonArray;

public class MyListPresenter implements MyContract.ContractForListPresenter {
    private MyModel model;
    private MyContract.ContractForListView view;

    public MyListPresenter(MyContract.ContractForListView view) {
        this.model = new MyModel();
        this.view = view;
    }

    @Override
    public void presenterSearch(String id, String keyword) {
        model.modelSearch(keyword, new MyModel.MyListener_search() {
            @Override
            public void onResponse(JsonArray array) {
                view.goAdapter(id, array);
            }
        });
    }

    @Override
    public void presenterBack() {
        view.goTitle();
    }

    @Override
    public void presenterScrap(String id) {
        view.goScrap(id);
    }

}
