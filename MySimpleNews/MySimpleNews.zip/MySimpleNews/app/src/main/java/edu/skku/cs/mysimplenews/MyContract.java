package edu.skku.cs.mysimplenews;

import com.google.gson.JsonArray;

public interface MyContract {
    interface ContractForMainView {
        void showLoginSuccess(String id);
        void showLoginFail();
        void showSignupSuccess(String result);
        void showSignupFail();
    }

    interface ContractForListView {
        void goAdapter(String id, JsonArray array);
        void goTitle();
        void goScrap(String id);
    }

    interface ContractForScrapView {
        void show(String id, JsonArray array);
        void goBack2();
        void goBack3(String id);
    }

    interface ContractForMainPresenter {
        void presenterLogin(String id, String pw);
        void presenterSignup(String id, String pw);
    }

    interface ContractForListPresenter {
        void presenterSearch(String id, String keyword);
        void presenterBack();
        void presenterScrap(String id);
    }

    interface ContractForScrapPresenter {
        void presenterShow(String id);
        void presenterBack2();
        void presenterBack3(String id);
    }
}