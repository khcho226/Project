package edu.skku.cs.mysimplenews;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements MyContract.ContractForMainView {
    private MyContract.ContractForMainPresenter presenter_main;
    private EditText editText_id, editText_pw;
    private Button button_login, button_signup;

    public static final String EXT_ID = "ID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        editText_id = findViewById(R.id.editText_id);
        editText_pw = findViewById(R.id.editText_pw);
        button_login = findViewById(R.id.button_login);
        button_signup = findViewById(R.id.button_signup);

        presenter_main = new MyPresenter(this);

        button_login.setOnClickListener(view -> {
            presenter_main.presenterLogin(editText_id.getText().toString(), editText_pw.getText().toString());
        });

        button_signup.setOnClickListener(view -> {
                presenter_main.presenterSignup(editText_id.getText().toString(), editText_pw.getText().toString());
        });
    }

    @Override
    public void showLoginSuccess(String id) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Welcome " + id + "!", Toast.LENGTH_SHORT).show();
            }
        }, 0);

        Intent intent = new Intent(MainActivity.this, ListActivity.class);
        intent.putExtra(EXT_ID, id);
        startActivity(intent);
    }

    @Override
    public void showLoginFail() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Invalid Login!", Toast.LENGTH_SHORT).show();
            }
        }, 0);
    }

    @Override
    public void showSignupSuccess(String result) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Sign Up Complete!", Toast.LENGTH_SHORT).show();
            }
        }, 0);
    }

    @Override
    public void showSignupFail() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Invalid Sign Up!", Toast.LENGTH_SHORT).show();
            }
        }, 0);
    }
}