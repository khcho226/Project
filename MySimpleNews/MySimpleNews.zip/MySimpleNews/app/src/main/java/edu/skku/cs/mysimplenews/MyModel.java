package edu.skku.cs.mysimplenews;

import androidx.annotation.NonNull;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MyModel {
    static Object json_res = "";

    public void modelLogin(String id, String pw, MyListener_login listener) {
        OkHttpClient client = new OkHttpClient();
        String url = "https://c52rx458ga.execute-api.ap-northeast-2.amazonaws.com/dev/login";
        String json = "{\"id\":\"" + id + "\",\"pw\":\"" + pw + "\"}";
        Request req = new Request.Builder().url(url).post(RequestBody.create(MediaType.parse("application/json"), json)).build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();

                try {
                    JSONObject json = new JSONObject(myResponse);
                    json_res = json.get("success");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                listener.onResponse(json_res, id);
            }
        });
    }

    public void modelSignup(String id, String pw, MyListener_signup listener) {
        if (id.equals("") || pw.equals("")) {
            json_res = "false";
            listener.onResponse(json_res);
        }

        else {
            OkHttpClient client = new OkHttpClient();
            String url = "https://c52rx458ga.execute-api.ap-northeast-2.amazonaws.com/dev/adduser";
            String json = "{\"id\":\"" + id + "\",\"pw\":\"" + pw + "\"}";
            Request req = new Request.Builder().url(url).post(RequestBody.create(MediaType.parse("application/json"), json)).build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    final String myResponse = response.body().string();

                    try {
                        JSONObject json = new JSONObject(myResponse);
                        json_res = json.get("success");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    listener.onResponse(json_res);
                }
            });
        }
    }

    public void modelSearch(String keyword, MyListener_search listener) {
        Calendar calendar = Calendar.getInstance();
        String format = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        calendar.add(calendar.DATE, -30);
        String date = simpleDateFormat.format(calendar.getTime());

        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://newsapi.org/v2/everything").newBuilder();
        urlBuilder.addQueryParameter("q", keyword);
        urlBuilder.addQueryParameter("language", "en");
        urlBuilder.addQueryParameter("from", date);
        urlBuilder.addQueryParameter("pageSize", "15");
        urlBuilder.addQueryParameter("sortBy", "popularirty");
        urlBuilder.addQueryParameter("apiKey", "8846678911ba442aa932af8ad7b13582");
        String url = urlBuilder.build().toString();
        Request req = new Request.Builder().url(url).build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();

                JsonParser parser = new JsonParser();
                JsonObject object = (JsonObject) parser.parse(myResponse);
                JsonArray array = (JsonArray) object.get("articles");

                listener.onResponse(array);
            }
        });
    }

    public void modelGetscrap(String id, MyListener_getscrap listener) {
        OkHttpClient client = new OkHttpClient();
        String url = "https://c52rx458ga.execute-api.ap-northeast-2.amazonaws.com/dev/getscrap";
        String json = "{\"id\":\"" + id + "\"}";
        Request req = new Request.Builder().url(url).post(RequestBody.create(MediaType.parse("application/json"), json)).build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();

                JsonParser parser = new JsonParser();
                JsonObject object = (JsonObject) parser.parse(myResponse);
                JsonArray array = (JsonArray) object.get("final");

                listener.onResponse(array);
            }
        });
    }

    public interface MyListener_login {
        void onResponse(Object response, String id);
    }

    public interface MyListener_signup {
        void onResponse(Object response);
    }

    public interface MyListener_search {
        void onResponse(JsonArray array);
    }

    public interface MyListener_getscrap {
        void onResponse(JsonArray array);
    }
}