package edu.skku.cs.mysimplenews;

public class MyPresenter implements MyContract.ContractForMainPresenter {
    private MyModel model;
    private MyContract.ContractForMainView view;

    public MyPresenter(MyContract.ContractForMainView view) {
        this.model = new MyModel();
        this.view = view;
    }

    @Override
    public void presenterLogin(String id, String pw) {
        model.modelLogin(id, pw, new MyModel.MyListener_login() {
            @Override
            public void onResponse(Object response, String id) {
                if (response.toString().equals("true")) {
                    view.showLoginSuccess(id);
                }

                else {
                    view.showLoginFail();
                }
            }
        });
    }

    @Override
    public void presenterSignup(String id, String pw) {
        model.modelSignup(id, pw, new MyModel.MyListener_signup() {
            @Override
            public void onResponse(Object response) {
                if (response.toString().equals("true")) {
                    view.showSignupSuccess(response.toString());
                }

                else {
                    view.showSignupFail();
                }
            }
        });
    }
}