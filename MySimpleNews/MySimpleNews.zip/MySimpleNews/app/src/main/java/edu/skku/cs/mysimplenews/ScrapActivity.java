package edu.skku.cs.mysimplenews;

import static edu.skku.cs.mysimplenews.MainActivity.EXT_ID;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;

public class ScrapActivity extends AppCompatActivity implements MyContract.ContractForScrapView {
    private MyContract.ContractForScrapPresenter presenter_scrap;
    private Button button_back2, button_back3;

    private ListView listView;
    private ScrapAdapter scrapAdapter;
    private ArrayList<ListClass> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("My Scrap");

        button_back2 = findViewById(R.id.button_back2);
        button_back3 = findViewById(R.id.button_back3);

        Intent intent = getIntent();
        String id = intent.getStringExtra(EXT_ID);

        presenter_scrap = new MyScrapPresenter(this);
        presenter_scrap.presenterShow(id);

        button_back2.setOnClickListener(view -> {
            presenter_scrap.presenterBack2();
        });

        button_back3.setOnClickListener(view -> {
            presenter_scrap.presenterBack3(id);
        });
    }

    @Override
    public void show(String id, JsonArray array) {
        listView = findViewById(R.id.listView_scrap);
        items = new ArrayList<ListClass>();

        for (int i = 0; i < array.size(); i++) {
            JsonObject object = (JsonObject) array.get(i);
            String[] title = object.get("title").toString().split("\"");
            String[] description = object.get("description").toString().split("\"");
            String[] url = object.get("url").toString().split("\"");
            items.add(new ListClass(id, title[1], description[1], url[1]));
        }

        scrapAdapter = new ScrapAdapter(items, ScrapActivity.this);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                listView.setAdapter(scrapAdapter);
            }
        }, 0);
    }

    @Override
    public void goBack2() {
        Intent intent = new Intent(ScrapActivity.this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void goBack3(String id) {
        Intent intent = new Intent(ScrapActivity.this, ListActivity.class);
        intent.putExtra(EXT_ID, id);
        startActivity(intent);
    }
}