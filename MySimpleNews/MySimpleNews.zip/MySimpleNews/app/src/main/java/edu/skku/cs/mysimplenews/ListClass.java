package edu.skku.cs.mysimplenews;

public class ListClass {
    public String id;
    public String article_title;
    public String article_description;
    public String article_url;

    public ListClass(String id, String article_title, String article_description, String article_url) {
        this.id = id;
        this.article_title = article_title;
        this.article_description = article_description;
        this.article_url = article_url;
    }
}
