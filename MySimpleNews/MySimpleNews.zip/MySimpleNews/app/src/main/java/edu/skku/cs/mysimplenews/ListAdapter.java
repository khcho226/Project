package edu.skku.cs.mysimplenews;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ListAdapter extends BaseAdapter {
    private ArrayList<ListClass> items;
    private Context mContext;

    static Object json_res = "";

    ListAdapter (ArrayList<ListClass> items, Context mContext) {
        this.items = items;
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.list_layout, viewGroup, false);
        }

        TextView textView_art_title = view.findViewById(R.id.textView_art_title);
        TextView textView_art_description = view.findViewById(R.id.textView_art_description);
        Button button_url = view.findViewById(R.id.button_url);
        Button button_scrap = view.findViewById(R.id.button_scrap);

        String key = items.get(i).id + items.get(i).article_title;

        textView_art_title.setText(items.get(i).article_title);
        textView_art_description.setText(items.get(i).article_description);

        button_url.setOnClickListener(view_url -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(items.get(i).article_url));
            mContext.startActivity(intent);
        });

        button_scrap.setOnClickListener(view_scrap -> {
            OkHttpClient client = new OkHttpClient();
            String url = "https://c52rx458ga.execute-api.ap-northeast-2.amazonaws.com/dev/scrap";
            String json = "{\"key\":\"" + key + "\",\"id\":\"" + items.get(i).id + "\",\"title\":\"" + items.get(i).article_title + "\",\"description\":\"" + items.get(i).article_description + "\",\"url\":\"" + items.get(i).article_url + "\"}";
            Request req = new Request.Builder().url(url).post(RequestBody.create(MediaType.parse("application/json"), json)).build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    final String myResponse = response.body().string();

                    try {
                        JSONObject json = new JSONObject(myResponse);
                        json_res = json.get("success");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (json_res.toString().equals("true")) {
                                Toast.makeText(view_scrap.getContext(), "Scrap Complete!", Toast.LENGTH_SHORT).show();
                            }

                            else {
                                Toast.makeText(view_scrap.getContext(), "Invalid Scrap!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, 0);
                }
            });
        });

        return view;
    }
}
