package edu.skku.cs.mysimplenews;

import static edu.skku.cs.mysimplenews.MainActivity.EXT_ID;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity implements MyContract.ContractForListView {
    private MyContract.ContractForListPresenter presenter_list;
    private EditText editText_search;
    private Button button_search, button_back, button_scrap;

    private ListView listView;
    private ListAdapter listAdapter;
    private ArrayList<ListClass> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        editText_search = findViewById(R.id.editText_search);
        button_search = findViewById(R.id.button_search);
        button_back = findViewById(R.id.button_back);
        button_scrap = findViewById(R.id.button_myscrap);

        Intent intent = getIntent();
        String id = intent.getStringExtra(EXT_ID);

        presenter_list = new MyListPresenter(this);

        button_search.setOnClickListener(view -> {
            presenter_list.presenterSearch(id, editText_search.getText().toString());
        });

        button_back.setOnClickListener(view -> {
            presenter_list.presenterBack();
        });

        button_scrap.setOnClickListener(view -> {
            presenter_list.presenterScrap(id);
        });
    }

    @Override
    public void goAdapter(String id, JsonArray array) {
        listView = findViewById(R.id.listView_list);
        items = new ArrayList<ListClass>();

        for (int i = 0; i < array.size(); i++) {
            JsonObject object = (JsonObject) array.get(i);
            String[] title = object.get("title").toString().split("\"");
            String[] description = object.get("description").toString().split("\"");
            String[] url = object.get("url").toString().split("\"");
            items.add(new ListClass(id, title[1], description[1], url[1]));
        }

        listAdapter = new ListAdapter(items, ListActivity.this);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                listView.setAdapter(listAdapter);
            }
        }, 0);
    }

    @Override
    public void goTitle() {
        Intent intent = new Intent(ListActivity.this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    public void goScrap(String id) {
        Intent intent = new Intent(ListActivity.this, ScrapActivity.class);
        intent.putExtra(EXT_ID, id);
        startActivity(intent);
    }
}