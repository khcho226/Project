package edu.skku.cs.mysimplenews;

import com.google.gson.JsonArray;

public class MyScrapPresenter implements MyContract.ContractForScrapPresenter {
    private MyModel model;
    private MyContract.ContractForScrapView view;

    public MyScrapPresenter(MyContract.ContractForScrapView view) {
        this.model = new MyModel();
        this.view = view;
    }

    @Override
    public void presenterShow(String id) {
        model.modelGetscrap(id, new MyModel.MyListener_getscrap() {
            @Override
            public void onResponse(JsonArray array) {
                view.show(id, array);
            }
        });
    }

    @Override
    public void presenterBack2() {
        view.goBack2();
    }

    @Override
    public void presenterBack3(String id) {
        view.goBack3(id);
    }
}
